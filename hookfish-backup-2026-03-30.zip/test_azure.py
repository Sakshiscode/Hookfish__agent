import os
import azure.cognitiveservices.speech as speechsdk
from dotenv import load_dotenv

load_dotenv()

print("Testing Azure Speech Connectivity...")

try:
    speech_config = speechsdk.SpeechConfig(
        subscription=os.getenv('AZURE_SPEECH_KEY'), 
        region=os.getenv('AZURE_SPEECH_REGION')
    )
    
    # We pass audio_config=None so it doesn't try to play physically, just synthesizes to memory
    speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=None)

    print(f"Connecting to Region: {os.getenv('AZURE_SPEECH_REGION')}")
    
    result = speech_synthesizer.speak_text("नमस्ते, मैं स्वरा हूँ। Azure testing.")
    
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        print("[SUCCESS] Connected correctly! Everything works.")
    elif result.reason == speechsdk.ResultReason.Canceled:
        c = result.cancellation_details
        print(f"[FAIL] Error: {c.error_details}")
except Exception as e:
    print(f"Error: {e}")
