import os
import asyncio
from dotenv import load_dotenv
load_dotenv()

from livekit.plugins import sarvam

async def main():
    print("Testing Sarvam...")
    try:
        tts = sarvam.TTS(speaker="anushka", target_language_code="hi-IN")
        print("Synthesizing...")
        audio = tts.synthesize("Namaste.")
        async for chunk in audio:
            print("Received bytes:", len(chunk.data))
        print("Success!")
    except Exception as e:
        import traceback
        traceback.print_exc()

asyncio.run(main())
