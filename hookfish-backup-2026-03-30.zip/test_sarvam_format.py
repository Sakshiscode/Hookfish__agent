import os
import requests
import json
import base64
from dotenv import load_dotenv

load_dotenv()

def test_sarvam_native():
    api_key = os.getenv("sarvam_API_KEY")
    url = "https://api.sarvam.ai/text-to-speech"
    
    payload = {
        "target_language_code": "hi-IN",
        "text": "Hello world",
        "speaker": "simran",
        "model": "bulbul:v3"
    }
    
    headers = {
        "api-subscription-key": api_key,
        "Content-Type": "application/json"
    }
    
    print("Testing Sarvam v3 Simran...")
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        audios = data.get("audios", [])
        if audios:
            audio_bytes = base64.b64decode(audios[0])
            print(f"Success! Received {len(audio_bytes)} bytes.")
            print(f"First 16 bytes: {audio_bytes[:16].hex(' ')}")
            
            # Check for RIFF (WAV)
            if audio_bytes.startswith(b'RIFF'):
                print("Format detected: WAV")
            elif audio_bytes.startswith(b'\xff\xf3') or audio_bytes.startswith(b'\xff\xfb'):
                print("Format detected: MP3")
            else:
                print("Format unknown.")
        else:
            print("No audio chunks received.")
    else:
        print(f"Error: {response.status_code} - {response.text}")

if __name__ == "__main__":
    test_sarvam_native()
